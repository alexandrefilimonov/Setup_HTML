$a = 10;
$b=++;
echo "\$a=$a<br>\$b=$b";